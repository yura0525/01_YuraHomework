#include "TEnemyState.h"



TEnemyState::TEnemyState(TEnemy* pOwner) : m_pOwner(pOwner)
{
}


TEnemyState::~TEnemyState()
{
}
