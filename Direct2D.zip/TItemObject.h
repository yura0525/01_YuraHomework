#pragma once
#include "xObject.h"
class TItemObject : public xObject
{
public:
	bool Frame();

public:
	TItemObject();
	virtual ~TItemObject();
};

