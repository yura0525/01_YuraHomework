// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "TGameModeBase.h"
#include "LoginGameModeBase.generated.h"

/**
 * 
 */
UCLASS()
class GUISAMPLE_0_API ALoginGameModeBase : public ATGameModeBase
{
	GENERATED_BODY()
protected:
	virtual void ProcessPacket();
};
