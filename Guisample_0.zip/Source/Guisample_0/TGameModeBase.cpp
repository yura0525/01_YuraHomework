// Fill out your copyright notice in the Description page of Project Settings.

#include "TGameModeBase.h"
#include "TimerManager.h"
#include "LoginUserWidget.h"

void ATGameModeBase::BeginPlay()
{
	Super::BeginPlay();

	if (DefaultHUDClass != nullptr)
	{
		pMainWiz = CreateWidget<UUserWidget>(GetWorld(), DefaultHUDClass);
		if (pMainWiz != NULL)
		{
			pMainWiz->AddToViewport();
		}
		Cast<ULoginUserWidget>(pMainWiz)->ChattingMessage(FText::FromString("HAHAHAHAHA"));
	}

	FTimerHandle TimerHandle;

	//1/60�ʴ� �ݺ������� ATGameModeBase::ProcessPacket()ȣ��
	GetWorldTimerManager().SetTimer(TimerHandle, this, 
		&ATGameModeBase::ProcessPacket, 1.0f / 60.0f, true);
}

void ATGameModeBase::ProcessPacket()
{
	UE_LOG(LogClass, Log, TEXT("ProcessPacket()!!!!"));
}