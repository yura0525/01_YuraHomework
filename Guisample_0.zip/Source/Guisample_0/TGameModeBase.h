// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "Blueprint/UserWidget.h"
#include "TGameModeBase.generated.h"


/**
 * 
 */
UCLASS()
class GUISAMPLE_0_API ATGameModeBase : public AGameModeBase
{
	GENERATED_BODY()
public:
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "KGCA")
	TSubclassOf<class UUserWidget> DefaultHUDClass;

	UPROPERTY()
	class UUserWidget* pMainWiz;

public:
	virtual void BeginPlay() override;
protected:
	virtual void ProcessPacket();
};
