// Copyright 1998-2018 Epic Games, Inc. All Rights Reserved.

#include "Guisample_0GameMode.h"
#include "Guisample_0Character.h"
#include "UObject/ConstructorHelpers.h"

AGuisample_0GameMode::AGuisample_0GameMode()
{
	// set default pawn class to our Blueprinted character
	static ConstructorHelpers::FClassFinder<APawn> PlayerPawnBPClass(TEXT("/Game/ThirdPersonCPP/Blueprints/ThirdPersonCharacter"));
	if (PlayerPawnBPClass.Class != NULL)
	{
		DefaultPawnClass = PlayerPawnBPClass.Class;
	}
}
